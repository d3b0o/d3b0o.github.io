USE my_database;

CREATE TABLE mi_tabla (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(255),
    rol VARCHAR(255)
);

INSERT INTO mi_tabla (nombre, rol) VALUES
    ('Joan', 'admin'),
    ('Quim', 'user'),
    ('Andreu', 'user');

