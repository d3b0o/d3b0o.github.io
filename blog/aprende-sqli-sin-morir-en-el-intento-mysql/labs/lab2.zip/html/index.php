<?php
$host = 'db';
$database = 'mydatabase';
$user = 'myuser';
$password = 'mypassword';
$nombre = $_GET['nombre'];

try {
    $pdo = new PDO("pgsql:host=$host;dbname=$database;user=$user;password=$password");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $query = "SELECT * FROM mi_tabla WHERE nombre = '$nombre'";
    $stmt = $pdo->query($query);
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (count($result) > 0) {
        foreach ($result as $row) {
            echo "Nombre: " . $row["nombre"] . "<br>";
            echo "Rol: " . $row["rol"] . "<br>";
        }
    } else {
        echo "No se encontraron resultados.";
    }

} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>
