CREATE DATABASE mydatabase;

\c mydatabase;

CREATE TABLE mi_tabla (
    nombre VARCHAR(255),
    rol VARCHAR(255)
);

CREATE TABLE secret (
    username VARCHAR(255),
    password VARCHAR(255)
);


INSERT INTO mi_tabla (nombre, rol) VALUES
    ('joan', 'admin'),
    ('quim', 'user'),
    ('andreu', 'user');

INSERT INTO secret (username, password) VALUES
    ('admin', '1234'),
    ('joan', 'secret');
