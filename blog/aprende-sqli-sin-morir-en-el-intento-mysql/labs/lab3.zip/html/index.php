<?php
$nombre = $_GET['nombre'];

$mysqli = new mysqli(getenv('MYSQL_HOST'), getenv('MYSQL_USER'), getenv('MYSQL_PASSWORD'), getenv('MYSQL_DATABASE'));

if ($mysqli->connect_error) {
    die('Error de conexión: ' . $mysqli->connect_error);
}

$query = "SELECT * FROM mi_tabla WHERE nombre = '$nombre'";
$result = $mysqli->query($query);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "Nombre: " . $row["nombre"] . "<br>";
        echo "Rol: " . $row["rol"] . "<br>";
    }
} else {
    echo "";
}

$mysqli->close();
?>

